# Vampir Köylü Online

Gerçek zamanlı çok oyunculu HTML/Node.js oyunu. Oyuncular farklı telefonlardan aynı oda koduyla katılabilir.

## En kolay yayınlama (Render)

1. Bu ZIP'i bilgisayarına indirip aç.
2. İçindeki `vampir-koylu-online` klasörünü GitHub'a yeni bir repository olarak yükle.
3. Render.com hesabı aç ve **New + → Web Service** seçip GitHub repository'sini bağla.
4. Ayarlar:
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free (seçenek varsa)
5. Deploy tamamlanınca Render sana `https://...onrender.com` biçiminde bir adres verir. Bu adresi arkadaşlarına gönder.
6. Herkes siteyi açıp adını yazsın. Bir kişi oda oluştursun; çıkan kodu diğerleri girsin.

## Yerelde çalıştırma

Node.js 18+ kurulu olmalı. Klasörde terminal açıp:
```bash
npm install
npm start
```
Sonra tarayıcıdan `http://localhost:3000` adresini aç.

## Oyun özellikleri
- 5–12 oyuncu
- Oda koduyla katılım
- Gerçek zamanlı oda durumu ve olay akışı
- Sunucu tarafında gizli rol ataması
- Vampir gece hedef oylaması
- Kâhin araştırması (sonuç yalnızca kâhine görünür)
- Gündüz oylaması ve kazanma koşulları

## Bilmen gerekenler
- Oda verileri sunucu belleğinde tutulur; sunucu yeniden başlatılırsa aktif odalar sıfırlanır.
- Ücretsiz hosting ilk istekte yavaş uyanabilir.
- Bu prototipte sesli sohbet yoktur; tartışma için oyuncular kendi sesli görüşmelerini kullanabilir.
- Oyuncular bağlantıyı kaybederse odadan çıkarılır.
